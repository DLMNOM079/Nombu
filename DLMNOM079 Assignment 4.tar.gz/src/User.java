package src;

import java.util.ArrayList;

/** This is "User" class which implements the Comparable interface.It has three instance variables:
 *  "name", "description" of type String, and "lst" of type ArrayList<Posts>.  */
public class User implements Comparable<User> {
    String name;
    String description;
    ArrayList<Posts> postsArrayList = new ArrayList<>();

     /** Constructor for creating a new user object with a given name, description and list of posts. */
    public User(String name, String description, ArrayList<Posts> postsArrayList) {
        this.name = name;
        this.description = description;
    }

    public User(String name)
    {
        this.name = name;
        this.description = "";
    }

    /** This method takes a parameter of type "Posts" and adds it to the "lst" instance variable. */
    public void addPost(Posts post) {
        postsArrayList.add(post);
    }

    /**
    * Returns true if the post got deleted, else it returns false.
    */
    public boolean deletePost(String name)
    {
        int postToBeDeletedIndex = 0;
        boolean postExists = false;
        for (int index = 0; index < postsArrayList.size(); index++)
        {
            Posts post = postsArrayList.get(index);
            if (post.getTitle().equalsIgnoreCase(name))
            {
                postExists = true;
                postToBeDeletedIndex = index;
            }
        }

        if (postExists)
            postsArrayList.remove(postToBeDeletedIndex);

        return postExists;
    }

    /** This method returns the value of the "name" instance variable */
    public String getName() {
        return name;
    }

    /** This method takes a parameter of type "String" and sets the "name" instance variable to the given value */
    public void setName(String name) {
        this.name = name;
    }
    /** This method returns the "description" of a user. */
    public String getDescription() {
        return description;
    }
    /** This method takes a parameter of type "String" and sets the "description" instance variable to the given value */
    public void setDescription(String description) {
        this.description = description;
    }
     /** This method returns the ArrayList of "Posts" objects stored in the "lst" instance variable. */
    public ArrayList<Posts> getPostsArrayList() {
        return postsArrayList;
    }

     /** This method overrides the default "toString()" method of the Object class
      * and returns a string representation of the "User" object*/
    @Override
    public String toString() {
        return "User{"+
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", lst=" + postsArrayList +
                '}' ;
    }

    /** This method overrides the "compareTo()" method of the Comparable interface */
    @Override
    public int compareTo(User o) {
        return this.name.compareTo(o.name);
    }
}
