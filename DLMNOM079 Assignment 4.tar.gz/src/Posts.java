package src;

/** This is "Posts" class which implements the Comparable interface.It has three instance variables:
 *  "name", "description" of type String, and "lst" of type ArrayList<Posts>.  */
public class Posts{

    String title, video, likes;


     /** Constructor for creating a new post object with a given title, video and number of likes. */
    public Posts(String title, String video, String likes) {
        this.title = title;
        this.video = video;
        this.likes = likes;
    }
     /** This method returns the "title" of video */
    public String getTitle() {
        return title;
    }
    /** This method returns the number of likes */
    public String getLikes() {
        return likes;
    }

    /** This method returns the value of the "video" instance variable */
    public String getVideo() {
        return video;
    }

    /** This method takes a parameter of type "String" and sets the "title" instance variable to the given value */
    public void setTitle(String title) {
        this.title = title;
    }

    /** This method takes a parameter of type "String" and sets the "video" instance variable to the given value */
    public void setVideo(String video) {
        this.video = video;
    }

    /** This method takes a parameter of type "String" and sets the "number of likes" to the given value */
    public void setLikes(String likes) {
        this.likes = likes;
    }

    /** This method overrides the default "toString()" method of the Object class
     * and returns a string representation of the "Posts" object*/
    @Override

    public String toString() {
        return "\nTitle:" + title + "\n Video:"+ video + "\n Number of likes:" + likes;
    }
}
