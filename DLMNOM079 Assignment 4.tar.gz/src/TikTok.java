package src;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.lang.*;

/**
 * This class simulates a TikTok platform. It uses a Binary Search Tree data structure
 *  to store user accounts and their associated information, such as profile descriptions and posts
 */
public class TikTok {
    public static BinarySearchTree<User> bst = new BinarySearchTree<>();

    private BinaryTreeNode<User> findUserNode(String username)
    {
        return bst.find(new User(username));
    }



    public User findUser(String username)
    {
        return findUserNode(username).getData();
    }

    /**
     * Checks if a user account with the given username exists.
     * */
    public boolean userExists(String username)
    {
        User user = findUser(username);
        return user != null;
    }

    /**
     * Deletes a post given the username & post title.
     * */
    public boolean deletePost(String username, String postTitle)
    {

        User userWihPostToBeDeleted = findUser(username);

        return userWihPostToBeDeleted.deletePost(postTitle);
    }



    public static void main(String[] args) throws FileNotFoundException {

        Scanner line = new Scanner(System.in);
        TikTok tikTok = new TikTok();

        int choice = 0 ;
        while (choice != 8) {


            //  User interface

            System.out.println("Choose an action from the menu: \n1. Find the profile description for a given account " +
                    "\n2. List all accounts \n3. Create an account \n4. Delete an account \n5. Display all posts for a single account" +
                    " \n6. Add a new post for an account \n7. Load a file of actions from disk and process this " +
                    "\n8. Quit \n9.  delete a post for a user\nEnter your choice:");

            Scanner input = new Scanner(System.in);
            choice = input.nextInt();



             // Find the profile description for a given account

            if (choice == 1) {
                System.out.println("Enter the account name : ");
                String name = line.nextLine();
                if (tikTok.userExists(name))
                {
                    User user = tikTok.findUser(name);
                    System.out.println("The profile description is: " + user.getDescription());
                }
                else
                    System.out.println("User was not found.");


                 // List all accounts


            } else if (choice == 2) {


                bst.inOrder();


                // Create an account


            }else if (choice == 3) {

                System.out.println("Enter the account name: ");
                String name2 = line.nextLine();

                System.out.println("Enter the profile description: ");
                String des = line.nextLine();
                User user2 = new User(name2, des, null);


                // Insert a node to BST
                bst.insert(user2);


                 // deleting a user account


            } else if (choice == 4) {


                String confirmation  = "" ;
                System.out.println("Enter the account name : ");
                String name3 = line.nextLine();
                User user3 = new User(name3, null, null);
                User user9 = new User(name3, null, null);
                try {
                    user9 = bst.find(user3).data;
                    System.out.println("Are you sure you want to permanently remove "+ user3.getName() +" account from TikTok, press YES to proceed ");
                    Scanner confirm = new Scanner(System.in);
                    confirmation = confirm.nextLine();



                    if (confirmation.equalsIgnoreCase("YES")){
                        bst.delete(bst.find(user3).data); }
                    System.out.println(user3.getName()+" was removed successfully ");
                } catch (NullPointerException e) {
                    System.out.println("User not found.");
                }




                // Display all posts for a single account

            } else if (choice == 5) {
                //step 5
                //display posts
                System.out.println("Enter the account name : ");
                String name4 = line.nextLine();
                User user4 = new User(name4, null, null);

                try {
                    System.out.println(bst.find(user4).data.getPostsArrayList());
                } catch (NullPointerException e) {
                    System.out.println("User not found.");
                }

            }


             //Add a new post for an account


            else if (choice == 6) {

                System.out.println("Enter the account name : ");
                String name5 = line.nextLine();

                System.out.println("Enter the video title : ");
                String title = line.nextLine();

                System.out.println("Enter the video clip : ");
                String video = line.nextLine();

                System.out.println("Enter the number of likes : ");
                String No_likes = line.nextLine();

                Posts post = new Posts(title, video, No_likes);

                User user5 = new User(name5, null, null);

                BinaryTreeNode<User> node = bst.find(user5);
                //updating the existing node
                if (node != null && node.data != null) {
                    node.data.addPost(post);
                }


                // Load a file of actions from disk and process this
            } else if (choice == 7) {

                System.out.print("Enter the file name: ");
                String fileName = line.nextLine();
                File file = new File(fileName);
                Scanner fileline = new Scanner(file);


                while (fileline.hasNextLine()) {

                    String[] data = fileline.nextLine().split(" ");
                    if (data[0].equalsIgnoreCase("create")) {
                        create(data);
                    } else if (data[0].equalsIgnoreCase("add")) {
                        Add(data);

                    }
                }

            }


             // deleting a post for an account

            else if (choice == 9){
                System.out.println("Enter the account name : ");
                String name3 = line.nextLine();

                System.out.println("Enter the video title : ");
                String postTitle = line.nextLine();

                if (tikTok.userExists(name3))
                {
                    if (tikTok.deletePost(name3, postTitle))
                    {
                        System.out.println("Post was deleted.");
                    }
                    else
                        System.out.println("Post was not deleted.");
                }
                else
                    System.out.println("User was not found.");


            } else {
                System.exit(0);
            }
        }
    }

    /** A helper method that extracts data from a given string and creates a new User object
     * with a name and a description. It then inserts the new object into the binary search tree. */

        public static void create(String[] data){
        //get username and des
            String name = data[1];
            String des = "";
            for (int i = 2; i < data.length; i++) {
                des = des + data[i] + " ";
            }
            des.trim();

            //add user to BST
            // creating user object
            User user = new User(name,des,null);

            // insert a node to BST
            bst.insert(user);

        }

        /** A helper method that extracts data from a given string and creates a new Posts object
         *  with a title, video, and number of likes.It then adds the new post
         *  to the list of posts associated with a specific User object in the binary search tree. */

        public static void Add(String[] data){
            String name = data[1];
            String video = data[2];
            String likes = data[3];
            String title = "";
            for (int i = 4; i < data.length; i++) {
                title = title + data[i] + " ";
            }
            title.trim();

            //create a post object
            Posts post = new  Posts(title,video,likes);

            //create a helping user object
            User user = new User(name, null, null);

            BinaryTreeNode<User> node = bst.find(user) ;
            // updating the existing node
            if ( node != null && node.data != null) {
                node.data.addPost(post);
            }
        }

    }

